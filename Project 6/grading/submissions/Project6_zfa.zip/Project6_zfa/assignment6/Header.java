/* MULTITHREADING <MyClass.java>
 * EE422C Project 6 submission by
 * Zahra Atzuri
 * zfa84
 * 15500
 * Slip days used: <0>
 * Spring 2018
 */

package assignment6;
